USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =======================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/10/2021
-- Description:	Dynamically generates stored procedure to populate column SSN in 'temporary' table
--              [KfxMrgFormRcon_OnBase_Buffer]. Records are filtered by itemdata. 
--
-- Usage:   	Generated stored procedure will be called by KofaxMargoFormRecon application.
-- =======================================================================================================

DECLARE @KeytypeNumSSN           varchar(120);    -- bigint;
DECLARE @SSNTableName            nvarchar(400);

DECLARE @query	  nvarchar(max);

-- determine keytype number for SSN
SELECT @query = (N'SELECT @outKeyNum = keytypenum FROM [OnBase].[hsi].[keytypetable] WHERE keytype like ''SSN%''');
EXECUTE sp_executesql @query, N'@outKeyNum varchar(12) out', @outKeyNum = @KeytypeNumSSN OUT;
-- set SSN table name
SET @SSNTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumSSN) + N']';


--      make sure stored procedure exists
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_PopulateBuffer_SSN]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE OB_KfxMrgFormRcon_PopulateBuffer_SSN AS RETURN');

SET @query = 
    N'ALTER PROCEDURE [dbo].[OB_KfxMrgFormRcon_PopulateBuffer_SSN] (' +  CHAR(13) + CHAR(10) +
	'@MinItemnum BIGINT, @MaxItemnum BIGINT, @ReturnRowCounts INT OUT, @ReturnResult BIT OUT) ' + CHAR(13) + CHAR(10) +
	'AS ' +  CHAR(13) + CHAR(10) +
	'BEGIN ' +  CHAR(13) + CHAR(10) +
    '  DECLARE @SysError INT; DECLARE @SysRowCount INT; SET @SysError = 0; ' + CHAR(13) + CHAR(10) +
	'  INSERT INTO KfxMrgFormRcon_OnBase_Buffer (SSN) ' + CHAR(13) + CHAR(10) +
	'  SELECT CAST(Ssn.keyvaluechar as varchar(20)) as SSN ' + CHAR(13) + CHAR(10) +
	'  FROM  KfxMrgFormRcon_OnBase_Buffer Buff ' + CHAR(13) + CHAR(10) +
	'  INNER JOIN ' + @SSNTableName + ' Ssn ON Buff.Itemnum = Ssn.itemnum ' + CHAR(13) + CHAR(10) +
    '  WHERE Ssn.itemnum >= @MinItemnum AND Ssn.itemnum <= @MaxItemnum ' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) + 

    '  SELECT 	@SysError = @@ERROR, @SysRowCount = @@ROWCOUNT; ' + CHAR(13) + CHAR(10) +
	'  IF @SysError <> 0 ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnResult = 0; SET @ReturnRowCounts = 0; RETURN; ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
	'  ELSE ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnRowCounts = @SysRowCount; SET @ReturnResult = 1 ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
    'END;';

EXEC(@query);

