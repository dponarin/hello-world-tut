USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =======================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/10/2021
-- Description:	Dynamically generates stored procedure to populate column Account in 'temporary' table
--              [KfxMrgFormRcon_OnBase_Buffer]. Records are filtered by itemdata. 
--
-- Usage:   	Generated stored procedure will be called by KofaxMargoFormRecon application.
-- =======================================================================================================

DECLARE @KeytypeNumAcct           varchar(120);    -- bigint;
DECLARE @AcctTableName            nvarchar(400);

DECLARE @query	  nvarchar(max);

-- determine keytype number for Account
SELECT @query = (N'SELECT @outKeyNum = keytypenum FROM [OnBase].[hsi].[keytypetable] WHERE keytype like ''Account Nu%''');
EXECUTE sp_executesql @query, N'@outKeyNum varchar(12) out', @outKeyNum = @KeytypeNumAcct OUT;
-- set Account table name
SET @AcctTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumAcct) + N']';


--      make sure stored procedure exists
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_PopulateBuffer_Acct]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE OB_KfxMrgFormRcon_PopulateBuffer_Acct AS RETURN');

SET @query = 
    N'ALTER PROCEDURE [dbo].[OB_KfxMrgFormRcon_PopulateBuffer_Acct] (' +  CHAR(13) + CHAR(10) +
	'@MinItemnum BIGINT, @MaxItemnum BIGINT, @ReturnRowCounts INT OUT, @ReturnResult BIT OUT) ' + CHAR(13) + CHAR(10) +
	'AS ' +  CHAR(13) + CHAR(10) +
	'BEGIN ' +  CHAR(13) + CHAR(10) +
	'  DECLARE @SysError INT; DECLARE @SysRowCount INT; SET @SysError = 0; ' + CHAR(13) + CHAR(10) +
	'  INSERT INTO KfxMrgFormRcon_OnBase_Buffer (Account) ' + CHAR(13) + CHAR(10) +
	'  SELECT CAST(Acct.keyvaluechar as varchar(20)) as Account ' + CHAR(13) + CHAR(10) +
	'  FROM  KfxMrgFormRcon_OnBase_Buffer AS Buff ' + CHAR(13) + CHAR(10) +
	'  INNER JOIN ' + @AcctTableName + ' Acct ON Buff.Itemnum = Acct.itemnum ' + CHAR(13) + CHAR(10) +
    '  WHERE Acct.itemnum >= @MinItemnum AND Acct.itemnum <= @MaxItemnum ' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) + 

    '  SELECT 	@SysError = @@ERROR, @SysRowCount = @@ROWCOUNT; ' + CHAR(13) + CHAR(10) +
	'  IF @SysError <> 0 ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnResult = 0; SET @ReturnRowCounts = 0; RETURN; ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
	'  ELSE ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnRowCounts = @SysRowCount; SET @ReturnResult = 1 ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
    'END;';

EXEC(@query);
	