USE [master]

-- ===========================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/11/2021
-- Description:	Dynamically determines Service account for the current environment, ensures that corresponding
--              login and account exist, then creates a role, grants necessary permissions  to the role and 
--              add the service account to this role.
-- Usage:   	Will be run once as a part of application installation process.
-- ==========================================================================================================

-- --------------- Determine service account based on server name ---------------

-- leave @Environment blank for all environments except VM; in VM assign it value 'LOCAL'
DECLARE @Environment NVARCHAR (10) = ''

DECLARE @LOGINNAME   NVARCHAR(128)

IF   @Environment = 'LOCAL'                      -- Local VM
  BEGIN
	SET @LOGINNAME = 'DEVNCSECU\svc-dkfx-process'
  END
ELSE IF  (SELECT substring(@@SERVERNAME, 1, 1)) = 'D' AND (SELECT substring(@@SERVERNAME, 2, 3)) = 'SBX'     -- SANDBOX
  BEGIN
	SET @Environment = 'SANDBOX'
	SET @LOGINNAME = 'DEVNCSECU\svc-dkfx-process'   -- ???
  END
ELSE IF  (SELECT substring(@@SERVERNAME, 1, 1)) = 'D' AND (SELECT substring(@@SERVERNAME, 5, 1)) = '0'		-- DEV
  BEGIN
	SET @Environment = 'DEV'
	SET @LOGINNAME = 'DEVNCSECU\svc-dkfx-process'
  END
ELSE IF (SELECT substring(@@SERVERNAME, 1, 1)) = 'D' AND (SELECT substring(@@SERVERNAME, 5, 1)) = '2'   -- DEV2
  BEGIN
	SET @Environment = 'DEV2'
    SET @LOGINNAME = 'DEVNCSECU\svc-dkfx-process'   -- ???
  END
ELSE IF (SELECT substring(@@SERVERNAME, 1, 1)) = 'S'		-- SIT
  BEGIN
	SET @Environment = 'SIT'
	SET @LOGINNAME = 'NCSECU\svc-skfx-process'      -- ???
  END
ELSE IF (SELECT substring(@@SERVERNAME, 1, 1)) = 'U'		-- UAT
  BEGIN
	SET @Environment = 'UAT'
	SET @LOGINNAME = 'NCSECU\svc-tkfx-process'      -- ???
  END
ELSE IF (SELECT substring(@@SERVERNAME, 1, 1)) = 'P'		-- Prod
  BEGIN
	SET @Environment = 'PROD'
	SET @LOGINNAME = 'NCSECU\svc-pkfx-process'      -- ???
  END
ELSE 
  BEGIN
	PRINT 'ERROR - Unable to detect Environment'
	RETURN
  END;
  
PRINT 'Environment: ' + @Environment; 
PRINT 'Login Name: ' + @LOGINNAME;

-- --------------- Make sure that login and account exist in DB ReconHelper ---------------
USE [ReconHelper]

DECLARE @sqlstmt varchar(200);

-- check that server-level Login exists
IF  NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = @LOGINNAME)
BEGIN
    SET @sqlstmt = 'CREATE LOGIN [' + @LOGINNAME + '] FROM WINDOWS WITH DEFAULT_DATABASE=[ReconHelper], DEFAULT_LANGUAGE=[us_english]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END

-- check that service account exists
IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = @LOGINNAME)
BEGIN
	SET @sqlstmt = 'CREATE USER [' + @LOGINNAME + ']  FOR LOGIN [' + @LOGINNAME + '] WITH DEFAULT_SCHEMA=[dbo]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END

-- --------------- Grant permissions to the role and add service account to the role ---------------

-- make sure the role Role_KfxMargoFrmRecon exists
IF DATABASE_PRINCIPAL_ID('Role_KfxMargoFrmRecon') IS NULL
BEGIN
    CREATE ROLE [Role_KfxMargoFrmRecon] AUTHORIZATION [dbo]
END

GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON [dbo].[KfxMrgFormRcon_OnBase_MemdocRecords] TO [Role_KfxMargoFrmRecon];
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON [dbo].[KfxMrgFormRcon_OnBase_Buffer] TO [Role_KfxMargoFrmRecon];
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON [dbo].[KfxMrgFormRcon_OnBase_Itemtypenum] TO [Role_KfxMargoFrmRecon];

GRANT EXECUTE ON TYPE::dbo.list_varchar TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_GetMaxItemnum TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_TruncateTables TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_PopulateItemtypenumTable TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_PrePopulateBuffer TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_PopulateBuffer_SSN TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_PopulateBuffer_Acct TO [Role_KfxMargoFrmRecon];
GRANT EXECUTE ON OB_KfxMrgFormRcon_SelectRecords TO [Role_KfxMargoFrmRecon];

EXEC sp_addrolemember 'Role_KfxMargoFrmRecon', @LOGINNAME;
