USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

-- ====================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/07/2021
-- Description:	Table to hold OnBase records selected for processing by KofaxMargoFormRecon application
-- Usage:   	Will be called by KofaxMargoFormRecon application
-- ====================================================================================================
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KfxMrgFormRcon_OnBase_MemdocRecords]') AND type in (N'U'))
BEGIN
  CREATE TABLE [dbo].[KfxMrgFormRcon_OnBase_MemdocRecords](
	  [UniqueID] 	         [varchar](20) NOT NULL,
	  [DocDate] 	         [datetime] NULL,
	  [Account] 	         [varchar](20) NULL,
	  [SSN] 		         [varchar](11) NULL,
	  [Itemnum]              [bigint] NOT NULL,
	  [Itemtypenum]          [bigint] NOT NULL
  ) ON [PRIMARY]
 END

-- ====================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/07/2021
-- Description:	Table to hold all records from OnBase whose Itemnum is between Min and Max values, and
--              whose Doctype OnBase ID ('itemtypenum') there are in the table 
--              [KfxMrgFormRcon_OnBase_Doctypes]. 
-- Usage:	    Will be used by other scripts to populate table [KfxMrgFormRcon_OnBase_MemdocRecords]
-- ====================================================================================================
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KfxMrgFormRcon_OnBase_Buffer]') AND type in (N'U'))
BEGIN
  CREATE TABLE [dbo].[KfxMrgFormRcon_OnBase_Buffer](
	  [UniqueID] 	         [varchar](20) NOT NULL,
	  [DocDate] 	         [datetime] NULL,
	  [Account] 	         [varchar](20) NULL,
	  [SSN] 		         [varchar](11) NULL,
	  [Itemnum]              [bigint] NOT NULL,
	  [Itemtypenum] [bigint] NOT NULL
  ) ON [PRIMARY]
END

-- ====================================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/10/2021
-- Description:	Table to hold itemdata.itemtypenum that correspond to UniqueID in the list received from C# application
--                 Column 'UniqueID' contains UniqueIDs
-- Usage:   	List of distinct Itemtypenum from this table will be used for filtering records selected from OnBase.
-- =====================================================================================================================
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KfxMrgFormRcon_OnBase_Itemtypenum]') AND type in (N'U'))
BEGIN
  CREATE TABLE [dbo].[KfxMrgFormRcon_OnBase_Itemtypenum](
      [Itemtypenum]   [bigint] NULL,
	  [UniqueID]      [varchar](20) NULL
  ) ON [PRIMARY]
END

GO
