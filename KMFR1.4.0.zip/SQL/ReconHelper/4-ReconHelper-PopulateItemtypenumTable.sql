USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ========================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/11/2021
-- Description:	Dynamically generates stord procedure to populate table [KfxMrgFormRcon_OnBase_Itemtypenum]
--              with all UniqueID from the list sent by C# application and corresponding Itemtypenum values
-- Usage:   	Will be called by KofaxMargoFormRecon application
-- ========================================================================================================

-- ---------- Dynamically determine environment-specific table name for UniqueID table ---------

DECLARE @KeytypeNumUniqID     varchar(120);    -- bigint;     
DECLARE @UniqIDTableName      nvarchar(400);
DECLARE @query	  nvarchar(max);

-- determine keytype number for UniqueID
SELECT @query = (N'SELECT @outKeyNum = keytypenum FROM [OnBase].[hsi].[keytypetable] WHERE keytype like ''SOURCE UNI%''');
EXECUTE sp_executesql @query, N'@outKeyNum varchar(12) out', @outKeyNum = @KeytypeNumUniqID OUT;

-- set @UniqIDTableName
SET @UniqIDTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumUniqID) + N']';


-- --------- Dynamically generate stored procedure ---------

-- make sure user-defined type exists
IF TYPE_ID(N'[dbo].[list_varchar]') IS NULL
    EXEC('CREATE TYPE dbo.list_varchar AS TABLE (id varchar(20) NOT NULL PRIMARY KEY);')

-- make sure stored procedures exists
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_PopulateItemtypenumTable]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE OB_KfxMrgFormRcon_PopulateItemtypenumTable AS RETURN');

DECLARE @sqlstmt nvarchar(MAX);

SET @sqlstmt = 
    N'ALTER PROCEDURE [dbo].[OB_KfxMrgFormRcon_PopulateItemtypenumTable] (' +  CHAR(13) + CHAR(10) +
	'@id_list list_varchar READONLY, @ReturnResult BIT OUT) ' + CHAR(13) + CHAR(10) +
	'AS ' +  CHAR(13) + CHAR(10) +
	'BEGIN ' +  CHAR(13) + CHAR(10) +
    '  DECLARE @SysError INT; SET @SysError = 0; ' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	'  INSERT INTO KfxMrgFormRcon_OnBase_Itemtypenum(Itemtypenum, UniqueID) ' + CHAR(13) + CHAR(10) +
	'  SELECT Itemdata.itemtypenum AS Itemtypenum, CAST(Uid.keyvaluechar as varchar(20)) AS UniqueID ' + CHAR(13) + CHAR(10) +
    '  FROM ' + @UniqIDTableName + ' AS Uid ' + CHAR(13) + CHAR(10) +
    '  INNER JOIN [OnBase].[hsi].[itemdata] AS Itemdata ON Uid.itemnum = Itemdata.itemnum ' + CHAR(13) + CHAR(10) +
	'  WHERE Uid.keyvaluechar IN (SELECT id FROM @id_list);' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	
    '  SELECT 	@SysError = @@ERROR; ' + CHAR(13) + CHAR(10) +
	'  IF @SysError <> 0 ' + CHAR(13) + CHAR(10) +
	'    SET @ReturnResult = 0; ' + CHAR(13) + CHAR(10) +
	'  ELSE ' + CHAR(13) + CHAR(10) +
	'    SET @ReturnResult = 1 ' + CHAR(13) + CHAR(10) +
    'END;';

EXEC(@sqlstmt);
