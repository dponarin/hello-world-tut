USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =======================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/10/2021
-- Description:	Dynamically generates stored procedure to populate several columns in 'temporary' table
--              [KfxMrgFormRcon_OnBase_Buffer]. Records are filtered by itemdata, status, and by 
--              itemtypenum. Records are selected without checking if their UniqueID there is in the list.
--
-- Usage:   	Generated stored procedure will be called by KofaxMargoFormRecon application.
-- =======================================================================================================

-- -------- Dynamically determine environment-dependent table name for UniqueID table ---------

DECLARE @KeytypeNumUniqID        varchar(120);    -- bigint;     
DECLARE @UniqIDTableName         nvarchar(400);
DECLARE @KeytypeNumLegacySrc     varchar(120);    -- bigint;     
DECLARE @LegacySrcTableName      nvarchar(400);

DECLARE @query	  nvarchar(max);

-- determine keytype number for UniqID
SELECT @query = (N'SELECT @outKeyNum = keytypenum FROM [OnBase].[hsi].[keytypetable] WHERE keytype like ''SOURCE UNI%''');
EXECUTE sp_executesql @query, N'@outKeyNum varchar(12) out', @outKeyNum = @KeytypeNumUniqID OUT;	
-- set UniqueID table name
SET @UniqIDTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumUniqID) + N']';

-- determine keytype number for LegacySource
SELECT @query = (N'SELECT @outKeyNum = keytypenum FROM [OnBase].[hsi].[keytypetable] WHERE keytype like ''LEGACY SOU%''');
EXECUTE sp_executesql @query, N'@outKeyNum varchar(12) out', @outKeyNum = @KeytypeNumLegacySrc OUT;	
-- set UniqueID table name
SET @LegacySrcTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumLegacySrc) + N']';

-- --------- Dynamically generate stored procedure ---------

--  make sure stored procedure is defined
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_PrePopulateBuffer]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE OB_KfxMrgFormRcon_PrePopulateBuffer AS RETURN');


-- generate stored procedure

SET @query = 
    N'ALTER PROCEDURE [dbo].[OB_KfxMrgFormRcon_PrePopulateBuffer] (' +  CHAR(13) + CHAR(10) +
	'@MinItemnum BIGINT, @MaxItemnum BIGINT, @ReturnRowCounts INT OUT, @ReturnResult BIT OUT) ' + CHAR(13) + CHAR(10) +
	'AS ' +  CHAR(13) + CHAR(10) +
	'BEGIN ' +  CHAR(13) + CHAR(10) +
    '  DECLARE @SysError INT; DECLARE @SysRowCount INT; SET @SysError = 0; ' + CHAR(13) + CHAR(10) +
	'  INSERT INTO KfxMrgFormRcon_OnBase_Buffer (UniqueID, DocDate, Itemnum, Itemtypenum) ' + CHAR(13) + CHAR(10) +
	'  SELECT CAST(Uid.keyvaluechar as varchar(20)) as UniqueID, Itemdata.itemdate as DocDate, Itemdata.itemnum AS Itemnum, Itemdata.itemtypenum AS Itemtypenum ' + CHAR(13) + CHAR(10) +
	'  FROM ' + @UniqIDTableName + ' Uid ' + CHAR(13) + CHAR(10) +
    '  INNER JOIN [OnBase].[hsi].[itemdata] AS Itemdata ON Uid.itemnum = Itemdata.itemnum ' + CHAR(13) + CHAR(10) +
	'  LEFT OUTER JOIN ' + @LegacySrcTableName + ' LegacySrc ON Uid.itemnum = LegacySrc.itemnum' + CHAR(13) + CHAR(10) +
    '  WHERE Itemdata.itemnum >= @MinItemnum AND Itemdata.itemnum <= @MaxItemnum AND ' + CHAR(13) + CHAR(10) + 
	'        Itemdata.status = 0 AND ' + CHAR(13) + CHAR(10) +
	'        LegacySrc.keyvaluechar IS NULL AND ' + CHAR(13) + CHAR(10) +
	'        Itemdata.itemtypenum IN (' + CHAR(13) + CHAR(10) +
    '                          SELECT DISTINCT Itemtypenum ' + CHAR(13) + CHAR(10) +
	'                          FROM [dbo].[KfxMrgFormRcon_OnBase_Itemtypenum] ' + CHAR(13) + CHAR(10) +
	'        );' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	
    '  SELECT 	@SysError = @@ERROR, @SysRowCount = @@ROWCOUNT; ' + CHAR(13) + CHAR(10) +
	'  IF @SysError <> 0 ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnResult = 0; SET @ReturnRowCounts = 0; RETURN; ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
	'  ELSE ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnRowCounts = @SysRowCount; SET @ReturnResult = 1 ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
    'END;';

EXEC(@query);

