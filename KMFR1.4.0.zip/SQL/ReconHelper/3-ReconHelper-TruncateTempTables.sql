USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/07/2021
-- Description:	Table will be truncated at the begging of the process 
-- Execution:	Will be called by "KofaxMargoFormRecon" application
-- ===============================================================================================

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_TruncateTables]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE dbo.OB_KfxMrgFormRcon_TruncateTables AS RETURN; ');
GO

ALTER PROCEDURE OB_KfxMrgFormRcon_TruncateTables
(
	@ReturnResult	BIT OUT
) 
AS
BEGIN
    DECLARE @SysError				INT;
	
	    -- Delete existing records, if any
        TRUNCATE TABLE KfxMrgFormRcon_OnBase_MemdocRecords
		
		-- Capture values as it will be reset to zero in next step
		SELECT 	@SysError = @@ERROR
		
		IF @SysError <> 0
			BEGIN
				SET @ReturnResult = 0		-- "BAD" result	
				RETURN						-- End further processing
			END
		ELSE
		    BEGIN
			    TRUNCATE TABLE KfxMrgFormRcon_OnBase_Buffer
				SELECT 	@SysError = @@ERROR;
				IF @SysError <> 0
				    BEGIN
					    SET @ReturnResult = 0		-- "BAD" result
						RETURN						-- End further processing
					END
				ELSE
					BEGIN
						TRUNCATE TABLE KfxMrgFormRcon_OnBase_Itemtypenum
						SELECT 	@SysError = @@ERROR
						IF @SysError <> 0
							BEGIN
								SET @ReturnResult = 0		-- "BAD" result
								RETURN						-- End further processing
							END
						ELSE
						    SET @ReturnResult = 1		-- "GOOD" result
					END				
			END
-- -------------------------------------------------------------------------------
END;  -- End stored procedure "OB_KfxMrgFormRcon_TruncateTables"