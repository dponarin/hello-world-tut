USE [ReconHelper]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/07/2021
-- Description:	Stored Procedure that selects records for Recon process from 'temporary' table 
--              [KfxMrgFormRcon_OnBase_Buffer] into the table [KfxMrgFormRcon_OnBase_MemdocRecords] 
--              whose UniqueID there is in the list.
-- Execution:	Will be called by "KofaxMargoFormRecon" application
-- ===================================================================================================

--      make sure stored procedure exists
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_SelectRecords]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE dbo.OB_KfxMrgFormRcon_SelectRecords AS RETURN; ');
GO

ALTER PROCEDURE OB_KfxMrgFormRcon_SelectRecords
(
	@ReturnRowCounts INT OUT, @ReturnResult	BIT OUT
) 
AS
BEGIN
    DECLARE @SysError	INT;
	DECLARE @SysRowCount INT;

	INSERT INTO [dbo].[KfxMrgFormRcon_OnBase_MemdocRecords] (UniqueID, DocDate, Account, SSN, Itemnum, Itemtypenum)
	SELECT UniqueID, DocDate, Account, SSN, Itemnum, Itemtypenum
	FROM [dbo].[KfxMrgFormRcon_OnBase_Buffer]
	WHERE UniqueID IN (SELECT UniqueID FROM KfxMrgFormRcon_OnBase_Itemtypenum);
	
    SELECT 	@SysError = @@ERROR, @SysRowCount = @@ROWCOUNT; 
	IF @SysError <> 0
	    BEGIN
		    SET @ReturnResult = 0;		-- "BAD" result
			SET @ReturnRowCounts = 0; 
			RETURN;
        ENd
	ELSE
	    BEGIN
	        SET @ReturnResult = 1;		-- "GOOD" result
			SET @ReturnRowCounts = @SysRowCount;
		END
-- -------------------------------------------------------------------------------
END;  -- End stored procedure "OB_KfxMrgFormRcon_SelectRecords"