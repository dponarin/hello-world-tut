USE [ReconHelper]
GO

-- ======================================================================================================
-- Author:      Dmitri Ponarin
-- Create date: 05/11/2021
-- Description:	Stored Procedure to retrieve current Maximun itemnum from table [OnBase].[hsi].[itemdata]
-- Usage:   	Will be called by KofaxMargoFormRecon application
-- ======================================================================================================

--  make sure stored procedure exists
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OB_KfxMrgFormRcon_GetMaxItemnum]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE OB_KfxMrgFormRcon_GetMaxItemnum AS RETURN');
GO

ALTER PROCEDURE [dbo].[OB_KfxMrgFormRcon_GetMaxItemnum] 
(
    @ReturnResult BIT OUT, 
	@MaxItemnum BIGINT OUT
)
AS
BEGIN
    DECLARE @SysError INT; SET @SysError = 0; SET @MaxItemnum = 0;
    SELECT @MaxItemnum = MAX(itemnum) 
	FROM [OnBase].[hsi].[itemdata];
	
    SELECT 	@SysError = @@ERROR;
	IF @SysError <> 0 
	    BEGIN
		    SET @ReturnResult = 0;   -- "BAD" result
			SET @MaxItemnum = 0; 
			RETURN; 
		END
	ELSE
	    BEGIN
		    SET @ReturnResult = 1;   -- "GOOD" result
	    END
END;


