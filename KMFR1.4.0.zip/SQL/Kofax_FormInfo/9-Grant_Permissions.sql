USE [Kofax_FormInfo]
GO

-- ===============================================================================================
-- Author:       Dmitri Ponarin
-- Create date:  12/09/2020
-- Description:	 Grants necessary permissions to service account.
--                 These changes are valid for following applications: 
--	               1 - Kofax Index Recon - Nightly and weekly process
--                 2 - Kofax Margo Form Recon
--                 3 - Kofax Margo Branch Scan Report
-- 	               4 - Kofax Index Recon User Interface (UI)
--                 5 - Kofax UID Batch class
-- Execution:	 Run ONCE in each environment during initial set up in target database	

-- NOTE: Update @KFX_ServiceAccount for target environment
-- ===============================================================================================

DECLARE @KFX_ServiceAccount varchar(40);

-- NOTE: Update @KFX_ServiceAccount for target environment
SET @KFX_ServiceAccount = 'DEVNCSECU\svc-dkfx-process';

DECLARE @sqlstmt varchar(2000);

-- Permissions for database Tables
SET @sqlstmt =
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormInfo TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.ExecutionHistory TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormIDs_To_Process TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.KfxMrgFormRcon_OnBase_MemdocRecords TO [' + @KFX_ServiceAccount + ']; ' ;
--PRINT @sqlstmt;
EXEC(@sqlstmt);

-- Permissions for database stored procedures
SET @sqlstmt =
    ' GRANT EXECUTE ON KfxMrgFormRcon_SelectRecFromKofaxInfo TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT EXECUTE ON KfxMrgFormRcon_UpdtRecScannedButMissingInOnBase TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT EXECUTE ON KfxMrgFormRcon_UpdateFormInfoTable TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT EXECUTE ON KfxMrgFormRcon_UpdtRecNotScanned TO [' + @KFX_ServiceAccount + ']; ' +
    ' GRANT EXECUTE ON KfxMrgFormRcon_TruncateTables TO [' + @KFX_ServiceAccount + ']; ' ;    
--PRINT @sqlstmt;
EXEC(@sqlstmt);

GO
