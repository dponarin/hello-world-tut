USE [Kofax_FormInfo]
GO

-- ===============================================================================================
-- Author:       Dmitri Ponarin
-- Create date:  12/09/2020
-- Description:	 Ensures that required login and user for service account exists in SQL server.
--                 These changes are valid for following applications: 
--	               1 - Kofax Index Recon - Nightly and weekly process
--                 2 - Kofax Margo Form Recon
--                 3 - Kofax Margo Branch Scan Report
-- 	               4 - Kofax Index Recon User Interface (UI)
--                 5 - Kofax UID Batch class
-- Execution:	 Run ONCE in each environment during initial set up in target database	

-- NOTE: Update Domain  and  UserID in  @KFX_ServiceAccount  for target environment
-- ===============================================================================================

DECLARE @KFX_ServiceAccount varchar(40);

-- NOTE: Update @KFX_ServiceAccount for target environment
SET @KFX_ServiceAccount = 'DEVNCSECU\svc-dkfx-process';

DECLARE @sqlstmt varchar(200);

IF  NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = @KFX_ServiceAccount)
BEGIN
    SET @sqlstmt = 'CREATE LOGIN [' + @KFX_ServiceAccount + '] FROM WINDOWS WITH DEFAULT_DATABASE=[Kofax_FormInfo], DEFAULT_LANGUAGE=[us_english]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END

IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = @KFX_ServiceAccount)
BEGIN
	SET @sqlstmt = 'CREATE USER [' + @KFX_ServiceAccount + ']  FOR LOGIN [' + @KFX_ServiceAccount + '] WITH DEFAULT_SCHEMA=[dbo]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END
GO
