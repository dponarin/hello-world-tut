﻿using System;
using System.Reflection;
using log4net;
using log4net.Config;

namespace KofaxMargoFormRecon
{
    class Program
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType.FullName);

        static void Main(string[] args)
        {
            // setup logger
            XmlConfigurator.Configure();

            Recon recon = new Recon(log);
            recon.StartRecon();
        }
    }
}
