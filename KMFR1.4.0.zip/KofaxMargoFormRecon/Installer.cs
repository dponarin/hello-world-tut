﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.IO;
using System.Windows.Forms;

namespace KofaxMargoFormRecon
{
    [RunInstaller(true)]
    public partial class Installer : System.Configuration.Install.Installer
    {
        public Installer()
        {
            InitializeComponent();
        }

        public override void Uninstall(IDictionary savedState)
        {
            if (savedState != null)
            {
                base.Uninstall(savedState);
            }
        }

        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
        }

        protected override void OnAfterInstall(IDictionary savedState)
        {
            base.OnAfterInstall(savedState);

            string configPath = Context.Parameters["assemblypath"] + ".config"; // fully qualifies name of config file
            if (!File.Exists(configPath))
            {
                MessageBox.Show(String.Format("Config file {0} does not exists. Installation failed.", configPath), "Installation failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Rollback(savedState);
                return;
            }

            ConfigurationForm confForm = new ConfigurationForm(configPath);
            confForm.TopLevel = true;

            DialogResult dialog = confForm.ShowDialog();
            if (dialog != DialogResult.OK)
            {
                MessageBox.Show("User cancelled installation.", "KofaxMargoFormRecon Installer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                throw new InstallException("User cancelled installation.");
            }

            if(!Recon.UpdateSettingValue(configPath, "LastSuccessfulRun", DateTime.Now.AddDays(-1).ToString("MM-dd-yyyy")))
            {
                string msg = string.Format(Properties.Settings.Default.Error_SettingUpdFailed, "LastSuccessfulRun", DateTime.Now.AddDays(-1).ToString("MM-dd-yyyy"), Environment.NewLine);
                MessageBox.Show(msg, "Failed to Update Setting", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            Recon.AddCommentToConfig(configPath, "MinItemnum", Properties.Resources.Comment_MinItemnum);

            if (!EncryptAppConfig(Context.Parameters["assemblypath"]))
            {
                MessageBox.Show(Properties.Settings.Default.Error_CannotEncrypt, "Encryption Failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// Encrypts connectionStrings section in App.config using Data Protection API (DPAPI).
        /// Helper method for  OnAfterInstall().
        /// </summary>
        /// <param name="exeFile">Fully qualified path to application .exe file</param>
        /// <returns>True if encrypted successfully.</returns>
        private bool EncryptAppConfig(string exeFile)
        {
            try
            {
                Configuration config = ConfigurationManager.OpenExeConfiguration(exeFile);
                ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;
                if (!section.SectionInformation.IsProtected)
                {
                    section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                    section.SectionInformation.ForceSave = true;
                }
                config.Save();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }

}
