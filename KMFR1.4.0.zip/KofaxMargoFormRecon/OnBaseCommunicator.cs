﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using log4net;

namespace KofaxMargoFormRecon
{
    public class OnBaseCommunicator
    {
        private static ILog log;
        internal static string spacer;
        internal SqlConnection onBaseConnection;

        public OnBaseCommunicator(ILog logger)
        {
            log = logger;
            spacer = "    ";
        }

        public bool GetMaxItemnum(out long maxItemnum)
        {
            try
            {
                log?.Info(spacer + "GetMaxItemnum(): Start");
                if (onBaseConnection == null || onBaseConnection.State != ConnectionState.Open)
                {
                    log?.Error(spacer + "GetMaxItemnum(): received SqlConnecton argument in the state that is not Open.");
                    maxItemnum = 0; // to make compiler happy
                    return false;
                }
                using (SqlCommand sqlCommand = onBaseConnection.CreateCommand())
                {
                    sqlCommand.CommandText = Properties.Settings.Default.SP_OnBase_GetMaxItemnum;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbTimeout_OnBase;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    SqlParameter retMaxItemnum = sqlCommand.Parameters.AddWithValue("@MaxItemnum", 0);
                    retMaxItemnum.Direction = ParameterDirection.Output;
                    retMaxItemnum.SqlDbType = SqlDbType.BigInt;

                    sqlCommand.ExecuteNonQuery();
                    if ((bool)retVal.Value)
                    {
                        // have to make sure that SP found any records and, hence, assigned a value to minItemnum
                        if (!DBNull.Value.Equals(retMaxItemnum.Value))
                        {
                            maxItemnum = (long)retMaxItemnum.Value;
                            log?.Info(spacer + "    " + $"SP '{Properties.Settings.Default.SP_OnBase_GetMaxItemnum}' read MAX itemnum value {maxItemnum}");
                            return true;
                        }
                        else
                        {
                            log?.Info(spacer + "    " + $"Stored procedure '{Properties.Settings.Default.SP_OnBase_GetMaxItemnum}' found no itemnums and  maxItemnum is set to 0");
                            maxItemnum = 0;
                            return true;
                        }
                    }
                    else
                    {
                        log?.Error($"SP '{Properties.Settings.Default.SP_OnBase_GetMaxItemnum}' has failed.");
                        maxItemnum = 0; // to make compiler happy
                        return false;
                    }
                }

            }
            catch (SqlException s)
            {
                log?.Error(spacer + "GetMaxItemnum() - SQL Exception: " + s.ToString());
                maxItemnum = 0;
                return false;
            }
            catch (TimeoutException t)
            {
                log?.Error(spacer + "GetMaxItemnum() - Timeout Exception: " + t.ToString());
                maxItemnum = 0;
                return false;
            }
            catch (Exception e)
            {
                log?.Error(spacer + "GetMaxItemnum() - Exception: " + e.ToString());
                maxItemnum = 0;
                return false;
            }
            finally
            {
                log?.Info(spacer + "GetMaxItemnum(): End");
            }
        }

        public DataSet FetchOnBaseData(List<String> uidList, long maxItemnum)
        {
            log?.Info(spacer + "FetchOnBaseData(): Start");
            if (onBaseConnection == null || onBaseConnection.State != ConnectionState.Open)
            {
                log?.Error("FetchOnBaseData(): received SqlConnecton argument in the state that is not Open.");
                Recon.SendErrorEmailMessage("SqlConnecton to ReconHelper database is not Open.");
                return null;
            }

            
            string tblName = Properties.Settings.Default.TableName_MemdocRecords; // for convenience
            try
            {
                DataSet resultDataset = new DataSet();

                if (!TruncateHelperDbTables(onBaseConnection))
                {
                    CloseOBConnection();
                    log?.Error($"Failed to truncate 'temporary' tables in ReconHelper database");
                    return null;
                }

                if (!RecordUidLists(uidList))
                {
                    string msg = $"Stored procedure [{Properties.Settings.Default.SP_OnBase_RecordUidList}] has failed to record contents of UniqueID list to a 'temporary' table in database ReconHelper. " + Environment.NewLine;
                    msg += "The application will continue execution despite of this issue.";
                    log?.Warn($"Non-fatal issue: " + msg);
                    Recon.SendWarningEmailMessage(msg);
                }

                if (uidList != null && uidList.Count > 0)
                {
                    if (!PopulateBuffer(Properties.Settings.Default.SP_OnBase_PopulateBuffer, maxItemnum))
                    {
                        CloseOBConnection();
                        log?.Error($"Failed to execute stored procedure [{Properties.Settings.Default.SP_OnBase_PopulateBuffer}] in database ReconHelper");
                        return null;
                    }

                    if (!(SelectRecordsForProcessing(Properties.Settings.Default.SP_OnBase_SelectRecords, uidList)))
                    {
                        CloseOBConnection();
                        log?.Error($"Failed to execute stored procedure [{Properties.Settings.Default.SP_OnBase_SelectRecords}] in database ReconHelper");
                        return null;
                    }
                }
                else
                {
                    log?.Info(spacer + "    List of UniqueIDs is empty");
                }
                
                resultDataset = ReadRecordsToDataSet(resultDataset, tblName, onBaseConnection);
                if (resultDataset == null)
                {
                    if (onBaseConnection.State == ConnectionState.Open) { onBaseConnection.Close(); }
                    log?.Error($"Failed to read records from ReconHelper DB table {tblName} to DataSet");
                    return null;
                }

                return resultDataset;
            }
            catch (SqlException s)
            {
                log?.Error(spacer + "FetchOnBaseData - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log?.Error(spacer + "FetchOnBaseData - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log?.Error(spacer + "FetchOnBaseData - Exception: " + e.ToString());
                return null;
            }
            finally
            {
                if (onBaseConnection != null && onBaseConnection.State != ConnectionState.Open)
                {
                    onBaseConnection.Close();
                }
                log?.Info(spacer + "FetchOnBaseData(): End");
            }

        }

        public bool OpenConnection(string connString)
        {
            onBaseConnection = Recon.OpenConnection(connString);
            if (onBaseConnection == null || onBaseConnection.State != ConnectionState.Open)
            {
                log?.Error("Failed to open DB connection to ReconHelper database");
                Recon.SendErrorEmailMessage("Failed to open DB connection to OnBase helper database");
                return false;
            }
            else
            {
                log?.Info(spacer + "Successfully open connection to ReconHelper database.");
                return true;
            }
        }

        public void CloseOBConnection()
        {
            if (onBaseConnection.State == ConnectionState.Open) { onBaseConnection.Close(); }
        }

        public DataSet ReadRecordsToDataSet(DataSet ds, string tableName, SqlConnection conn)
        {
            log?.Info(spacer + "ReadRecordsToDataSet(): Start");
            try
            {
                SqlDataAdapter readAdapter = new SqlDataAdapter();
                using (SqlCommand selectCommand = conn.CreateCommand())
                {
                    selectCommand.CommandText = Properties.Settings.Default.Query_OnBase_FetchRecords;
                    readAdapter.SelectCommand = selectCommand;
                    readAdapter.SelectCommand.CommandTimeout = Properties.Settings.Default.DbTimeout_OnBase;

                    readAdapter.Fill(ds, tableName);

                    log?.Info(spacer + "    " + $"Total number of records fetched from ReconHelper db to DataSet table [{tableName}]:  {ds.Tables[tableName].Rows.Count}");
                    return ds;
                }
            }
            catch (SqlException s)
            {
                log?.Error("ReadRecordsToDataSet - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log?.Error("ReadRecordsToDataSet - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log?.Error("ReadRecordsToDataSet - Exception: " + e.ToString());
                return null;
            }
            finally
            {
                log?.Info(spacer + "ReadRecordsToDataSet(): End");
            }
        }

        /// <summary>
        /// Calls stored procedure to record contents of list '<paramref name="uidList"/>' to 'temporary'
        /// table in ReconHelper database. SqlConnection to ReconHelper DB is assumed to be open.
        /// </summary>
        /// <param name="uidList"></param>
        /// <returns></returns>
        private bool RecordUidLists(List<String> uidList)
        {
            try
            {
                log?.Info(spacer + $"OnBaseCommunicator.RecordUidList: Start");
                if (onBaseConnection == null || onBaseConnection.State != ConnectionState.Open)
                {
                    log?.Error("OnBaseCommunicator.RecordUidList: SqlConnection to ReconHelper database is closed");
                    Recon.SendErrorEmailMessage("OnBaseCommunicator.RecordUidList: SqlConnection to ReconHelper database is closed");
                    return false;
                }
                using (SqlCommand sqlCommand = onBaseConnection.CreateCommand())
                {
                    sqlCommand.CommandText = Properties.Settings.Default.SP_OnBase_RecordUidList;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter paramList = sqlCommand.Parameters.AddWithValue("@id_list", CreateDataTable(uidList));
                    paramList.Direction = ParameterDirection.Input;
                    paramList.SqlDbType = SqlDbType.Structured;
                    paramList.TypeName = "dbo.list_varchar";

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();
                    if ((bool)retVal.Value)
                    {
                        log?.Info(spacer + "    " + $"Successfully recorded contents of UniqueID list to 'temporary' table in ReconHelper DB.");
                        return true;
                    }
                    else
                    {
                        log?.Error($"Failed to record contents of UniqueID list to 'temporary' tables in ReconHelper DB.");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log?.Error($"RecordUidLists() - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log?.Error($"RecordUidLists() - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log?.Error($"RecordUidLists() - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log?.Info(spacer + $"OnBaseCommunicator.RecordUidList: End");
            }
        }

        private bool TruncateHelperDbTables(SqlConnection sqlConn)
        {
            try
            {
                log?.Info(spacer + "OnBaseCommunicator.TruncateHelperDbTables(): Start");
                if (sqlConn == null || sqlConn.State != ConnectionState.Open)
                {
                    log?.Error("OnBaseCommunicator.TruncateHelperDbTables: SqlConnection to ReconHelper database is closed");
                    return false;
                }
                using (SqlCommand sqlCommand = sqlConn.CreateCommand())
                {
                    sqlCommand.CommandText = Properties.Settings.Default.SP_OnBase_TruncateTables;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();
                    if ((bool)retVal.Value)
                    {
                        log?.Info(spacer + "    " + $"Successfully truncated 'temporary' tables");
                        return true;   // leave connection open
                    }
                    else
                    {
                        log?.Error($"Failed to truncate 'temporary' tables");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log?.Error("OnBaseCommunicator.TruncateHelperDbTables - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log?.Error("OnBaseCommunicator.TruncateHelperDbTables - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log?.Error("OnBaseCommunicator.TruncateHelperDbTables - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log?.Info(spacer + "OnBaseCommunicator.TruncateHelperDbTables(): End");
            }
        }

        private bool PopulateBuffer(string spName, long maxItemnum)
        {
            try
            {
                log?.Info(spacer + $"OnBaseCommunicator.PopulateBuffer(): Start");
                if (onBaseConnection == null || onBaseConnection.State != ConnectionState.Open)
                {
                    log?.Error("OnBaseCommunicator.PopulateBuffer(): SqlConnection to ReconHelper database is closed");
                    return false;
                }
                using (SqlCommand sqlCommand = onBaseConnection.CreateCommand())
                {
                    sqlCommand.CommandText = spName;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbTimeout_OnBase;

                    SqlParameter inpMinItemnum = sqlCommand.Parameters.Add("@MinItemnum", SqlDbType.BigInt);
                    inpMinItemnum.Value = Properties.Settings.Default.MinItemnum;
                    inpMinItemnum.Direction = ParameterDirection.Input;

                    SqlParameter inpMaxItemnum = sqlCommand.Parameters.Add("@MaxItemnum", SqlDbType.BigInt);
                    inpMaxItemnum.Value = maxItemnum;
                    inpMaxItemnum.Direction = ParameterDirection.Input;

                    SqlParameter retCount = sqlCommand.Parameters.AddWithValue("@ReturnRowCounts", 0);
                    retCount.Direction = ParameterDirection.Output;
                    retCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();

                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retCount.Value;
                        log?.Info(spacer + "    " + $"SP '{spName}' successfully wrote {affectedRows} rows to 'buffer' table.");
                        return true;
                    }
                    else
                    {
                        log?.Error($"SP '{spName}' has failed.");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log?.Error($"OnBaseCommunicator.PopulateBuffer() - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log?.Error($"OnBaseCommunicator.PopulateBuffer() - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log?.Error($"OnBaseCommunicator.PopulateBuffer() - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log?.Info(spacer + $"OnBaseCommunicator.PopulateBuffer(): End");
            }
        }

        private bool SelectRecordsForProcessing(string spName, List<string> uidList)
        {
            try
            {
                log?.Info(spacer + $"SelectRecordsForProcessing.SelectRecordsForProcessing(): Start");
                if (onBaseConnection == null || onBaseConnection.State != ConnectionState.Open)
                {
                    log?.Error("OnBaseCommunicator.SelectRecordsForProcessing(): SqlConnection to ReconHelper database is closed");
                    return false;
                }
                using (SqlCommand sqlCommand = onBaseConnection.CreateCommand())
                {
                    sqlCommand.CommandText = spName;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbTimeout_OnBase;

                    SqlParameter paramUidList = sqlCommand.Parameters.AddWithValue("@id_list", CreateDataTable(uidList));
                    paramUidList.Direction = ParameterDirection.Input;
                    paramUidList.SqlDbType = SqlDbType.Structured;
                    paramUidList.TypeName = "dbo.list_varchar";

                    SqlParameter retCount = sqlCommand.Parameters.AddWithValue("@ReturnRowCounts", 0);
                    retCount.Direction = ParameterDirection.Output;
                    retCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();
                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retCount.Value;
                        log?.Info(spacer + "    " + $"SP '{spName}' successfully wrote {affectedRows} rows to table [{Properties.Settings.Default.TableName_MemdocRecords}]");
                        return true;
                    }
                    else
                    {
                        log?.Error($"SP '{spName}' has failed.");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log?.Error($"OnBaseCommunicator.SelectRecordsForProcessing() - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log?.Error($"OnBaseCommunicator.SelectRecordsForProcessing() - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log?.Error($"OnBaseCommunicator.SelectRecordsForProcessing() - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log?.Info(spacer + $"SelectRecordsForProcessing.SelectRecordsForProcessing(): End");
            }
        }

        /// <summary>
        /// Returns DateTime which is date in string '<paramref name="inputDate"/>' minus number of days in '<paramref name="daysBack"/>'.
        /// If '<paramref name="inputDate"/>' is empty or invalid or in future, it uses current date minus 7 days as '<paramref name="inputDate"/>' 
        /// (and writes warning to log file).
        /// </summary>
        /// <param name="inputDate"></param>
        /// <param name="daysBack"></param>
        /// <param name="emailSender"></param>
        /// <returns></returns>
        public DateTime GetLastSuccessfulRunDate(string inputDate, uint daysBack, Action<string> emailSender)
        {
            log?.Info(spacer + "Begin GetLastSuccessfulRunDate()");

            DateTime startDate;
            try
            {
                startDate = ReadDateFromString(inputDate);
            }
            catch (Exception ex)
            {
                log?.Error(spacer + "Error (non-fatal for the application) in GetLastSuccessfulRunDate. Exception: " + ex);
                startDate = DateTime.Now.Date.AddDays(-7);
                string msg = $"KofaxMargoFormRecon app has failed to read the date of last successful run from config file. " + 
                    $"The application will use date '{startDate.ToShortDateString()}' as a date of last succesful run.";
                log?.Warn(spacer + msg);
                emailSender(msg + " If this problem persist please notify BSD.");
            }

            // if last successful run is more than 10 days back send warning
            if (DateTime.Now.Date.AddDays(-10) > startDate)
            {
                string msg = $"Date of last successful run read from config file {startDate.ToShortDateString()} is more than 10 days back. " + Environment.NewLine;
                msg += $"Please research. One possible reason could be that service account {System.Security.Principal.WindowsIdentity.GetCurrent().Name} ";
                msg += "does not have Modify permission on application installation folder. If this problem persist please notify BSD.";
                log?.Warn(spacer + msg);
                emailSender(msg);
            }

            if (startDate > DateTime.Now.Date)
            {
                log?.Warn(spacer + $"Future date {startDate.ToShortDateString()} as a date of last succesful run was read from config file. " +
                    $"The application will use date '{DateTime.Now.Date.AddDays(-7).ToShortDateString()}' as a date of last succesful run.");
                log?.Info(spacer + "End GetLastSuccessfulRunDate()");
                return DateTime.Now.Date.AddDays(-7);
            }
            else
            {
                int daysOffset = -1 * (int)daysBack;
                startDate = startDate.AddDays(daysOffset);
                log?.Info(spacer + "Actual LastSuccessfulRun date used in the application is " + startDate.ToShortDateString());
                log?.Info(spacer + "End GetLastSuccessfulRunDate()");
                return startDate;
            }
        }

        /// <summary>
        /// Returns DateTime date parsed from the input string '<paramref name="inputDate"/>'. 
        /// Input string can represent date in several different formats normally used in US (month-day-year sequence). 
        /// When it fails to parse the date it throws FormatException.
        /// </summary>
        /// <param name="dateString"></param>
        /// <returns></returns>
        public DateTime ReadDateFromString(string dateString)
        {
            log?.Info(spacer + "Start ReadDateFromString()");
            DateTime parsedDate;
            string[] formats = { "MM-dd-yyyy", "MM-dd-yy", "M-d-yyyy", "M-d-yy", "MM/dd/yyyy", "MM/dd/yy", "M/d/yyyy", "M/d/yy",
                "MMddyyyy", "yyyyMMdd" };
            if (DateTime.TryParseExact(dateString, formats, new System.Globalization.CultureInfo("en-US"),
                System.Globalization.DateTimeStyles.None, out parsedDate))
            {
                log?.Info(spacer + $"    From string [{dateString}] parsed date: {parsedDate.ToLongDateString()}");
                log?.Info(spacer + "End ReadDateFromString()");
                return parsedDate;
            }
            else
            {
                log?.Warn(spacer + $"    Failed to parse string [{dateString}] to Date.");
                log?.Info(spacer + "End ReadDateFromString()");
                throw new FormatException($"Failed to parse string [{dateString}] to Date in format MM-dd-yyyy.");
            }
        }

        public DataTable CreateDataTable(IEnumerable<String> uidList)
        {
            DataTable table = new DataTable();
            table.Columns.Add("id", typeof(string));
            foreach (String uid in uidList)
            {
                table.Rows.Add(uid);
            }
            return table;
        }
    }
}
